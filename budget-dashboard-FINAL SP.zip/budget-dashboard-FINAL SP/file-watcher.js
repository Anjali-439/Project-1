// file-watcher.js - Watches for changes in Excel files and automatically reloads data
const fs = require('fs');
const path = require('path');

/**
 * Setup file watchers for Excel files
 * @param {string} expensesPath - Path to expenses Excel file
 * @param {string} incomePath - Path to income Excel file
 * @param {Function} reloadCallback - Function to call when files change
 */
function setupFileWatchers(expensesPath, incomePath, reloadCallback) {
  console.log(`Setting up file watchers for:
  - ${expensesPath}
  - ${incomePath}`);

  // Watch expenses file
  if (fs.existsSync(expensesPath)) {
    fs.watchFile(expensesPath, { interval: 5000 }, (curr, prev) => {
      console.log(`Expenses file changed: ${expensesPath}`);
      if (curr.mtime !== prev.mtime) {
        console.log('Detected change in expenses file, reloading data...');
        reloadCallback();
      }
    });
  } else {
    console.warn(`Cannot watch expenses file: ${expensesPath} (file not found)`);
  }

  // Watch income file
  if (fs.existsSync(incomePath)) {
    fs.watchFile(incomePath, { interval: 5000 }, (curr, prev) => {
      console.log(`Income file changed: ${incomePath}`);
      if (curr.mtime !== prev.mtime) {
        console.log('Detected change in income file, reloading data...');
        reloadCallback();
      }
    });
  } else {
    console.warn(`Cannot watch income file: ${incomePath} (file not found)`);
  }

  // Also watch the directory for new Excel files
  const expensesDir = path.dirname(expensesPath);
  const incomeDir = path.dirname(incomePath);

  // Only watch directories if they exist and are different
  if (fs.existsSync(expensesDir)) {
    fs.watch(expensesDir, (eventType, filename) => {
      if (filename && (filename.endsWith('.xlsx') || filename.endsWith('.xls'))) {
        console.log(`New or changed Excel file detected in expenses directory: ${filename}`);
        // Allow time for the file to be completely written
        setTimeout(reloadCallback, 1000);
      }
    });
  }

  // Only watch income directory if it's different from expenses directory
  if (fs.existsSync(incomeDir) && incomeDir !== expensesDir) {
    fs.watch(incomeDir, (eventType, filename) => {
      if (filename && (filename.endsWith('.xlsx') || filename.endsWith('.xls'))) {
        console.log(`New or changed Excel file detected in income directory: ${filename}`);
        // Allow time for the file to be completely written
        setTimeout(reloadCallback, 1000);
      }
    });
  }

  console.log('File watchers set up successfully');
  return true;
}

/**
 * Stop and clean up file watchers
 * @param {string} expensesPath - Path to expenses Excel file
 * @param {string} incomePath - Path to income Excel file
 */
function stopFileWatchers(expensesPath, incomePath) {
  console.log('Stopping file watchers...');

  if (fs.existsSync(expensesPath)) {
    fs.unwatchFile(expensesPath);
  }

  if (fs.existsSync(incomePath)) {
    fs.unwatchFile(incomePath);
  }

  console.log('File watchers stopped');
}

module.exports = {
  setupFileWatchers,
  stopFileWatchers
};