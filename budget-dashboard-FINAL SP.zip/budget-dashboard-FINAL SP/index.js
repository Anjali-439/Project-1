const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const xlsx = require('xlsx');
const financialService = require('./services/financialService');
const fileWatcher = require('./file-watcher');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Excel file paths - REPLACE WITH YOUR ACTUAL PATHS
const EXCEL_FILE_PATH = "/Users/sirishaarardhi/Downloads/Financial_Adv - Fixed Exp.numbers";
const INCOME_EXCEL_PATH = "/Users/sirishaarardhi/Downloads/Financial_Adv - Variable Exp.numbers";
;


// Initialize OpenAI with the key from financialService
financialService.setOpenAIKey();

// Load Excel data on server start
loadExcelData();

// Set up file watchers to automatically reload data when Excel files change
fileWatcher.setupFileWatchers(EXCEL_FILE_PATH, INCOME_EXCEL_PATH, () => {
  console.log('Auto-reloading Excel data due to file changes...');
  loadExcelData();
});

// Function to load Excel data dynamically
function loadExcelData() {
  try {
    console.log(`Reading Excel data from files...`);

    // Read and process the Excel files
    const excelData = readAndProcessExcel(EXCEL_FILE_PATH, INCOME_EXCEL_PATH);

    // Update the financial service with the Excel data
    financialService.updateFinancialData(excelData);

    console.log('Excel data loaded successfully');
    return true;
  } catch (error) {
    console.error('Error loading Excel data:', error);
    return false;
  }
}

// Function to read and process Excel file using improved method
function readAndProcessExcel(expensesPath, incomePath) {
  console.log(`Reading expenses from: ${expensesPath}`);
  console.log(`Reading income from: ${incomePath}`);

  // Default result structure
  const result = {
    income: [],
    expenses: []
  };

  // Process expenses file
  if (fs.existsSync(expensesPath)) {
    try {
      // Read the Excel file
      const workbook = xlsx.readFile(expensesPath, {
        cellFormula: true,
        cellStyles: true,
        cellDates: true
      });

      console.log('Expense file sheets:', workbook.SheetNames);

      // Process each sheet in the workbook
      workbook.SheetNames.forEach(sheetName => {
        const worksheet = workbook.Sheets[sheetName];

        // Convert to JSON for easier processing
        const jsonData = xlsx.utils.sheet_to_json(worksheet);
        console.log(`Found ${jsonData.length} rows in sheet: ${sheetName}`);

        if (jsonData.length > 0) {
          // Log the first row to see the structure
          console.log('Sample row:', jsonData[0]);

          // Process each row
          jsonData.forEach(row => {
            // Check if row contains Category and Amount fields (case insensitive)
            const categoryField = Object.keys(row).find(key =>
              key.toLowerCase() === 'category' || key.toLowerCase().includes('category'));

            const amountField = Object.keys(row).find(key =>
              key.toLowerCase() === 'amount' ||
              key.toLowerCase().includes('amount') ||
              key.includes('₹'));

            const descriptionField = Object.keys(row).find(key =>
              key.toLowerCase() === 'description' || key.toLowerCase().includes('description'));

            if (categoryField && amountField) {
              const category = row[categoryField];
              let amount = row[amountField];
              const description = descriptionField ? row[descriptionField] : '';

              // Skip empty categories or amounts
              if (!category || category === '') return;

              // Convert amount to number if it's a string
              if (typeof amount === 'string') {
                amount = parseFloat(amount.replace(/[^\d.-]/g, ''));
              }

              // Skip invalid amounts
              if (isNaN(amount) || amount <= 0) return;

              // If it's "Salary", add to income, otherwise to expenses
              if (String(category).toLowerCase() === 'salary') {
                result.income.push({
                  category: String(category),
                  amount: amount,
                  description: String(description || '')
                });
              } else {
                result.expenses.push({
                  category: String(category),
                  amount: amount,
                  description: String(description || '')
                });
              }
            }
          });
        }
      });
    } catch (err) {
      console.error('Error processing expenses file:', err);
    }
  } else {
    console.error('Expenses file does not exist:', expensesPath);
  }

  // Process income file (similar to expenses file)
  if (fs.existsSync(incomePath)) {
    try {
      // Read the Excel file
      const workbook = xlsx.readFile(incomePath, {
        cellFormula: true,
        cellStyles: true,
        cellDates: true
      });

      console.log('Income file sheets:', workbook.SheetNames);

      // Process each sheet in the workbook
      workbook.SheetNames.forEach(sheetName => {
        const worksheet = workbook.Sheets[sheetName];

        // Convert to JSON for easier processing
        const jsonData = xlsx.utils.sheet_to_json(worksheet);
        console.log(`Found ${jsonData.length} rows in sheet: ${sheetName}`);

        if (jsonData.length > 0) {
          // Log the first row to see the structure
          console.log('Sample row:', jsonData[0]);

          // Process each row
          jsonData.forEach(row => {
            // Check if row contains Category and Amount fields (case insensitive)
            const categoryField = Object.keys(row).find(key =>
              key.toLowerCase() === 'category' || key.toLowerCase().includes('category'));

            const amountField = Object.keys(row).find(key =>
              key.toLowerCase() === 'amount' ||
              key.toLowerCase().includes('amount') ||
              key.includes('₹'));

            const descriptionField = Object.keys(row).find(key =>
              key.toLowerCase() === 'description' || key.toLowerCase().includes('description'));

            if (categoryField && amountField) {
              const category = row[categoryField];
              let amount = row[amountField];
              const description = descriptionField ? row[descriptionField] : '';

              // Skip empty categories or amounts
              if (!category || category === '') return;

              // Convert amount to number if it's a string
              if (typeof amount === 'string') {
                amount = parseFloat(amount.replace(/[^\d.-]/g, ''));
              }

              // Skip invalid amounts
              if (isNaN(amount) || amount <= 0) return;

              // If it's "Salary", add to income, otherwise to expenses
              if (String(category).toLowerCase() === 'salary') {
                result.income.push({
                  category: String(category),
                  amount: amount,
                  description: String(description || '')
                });
              } else {
                result.expenses.push({
                  category: String(category),
                  amount: amount,
                  description: String(description || '')
                });
              }
            }
          });
        }
      });
    } catch (err) {
      console.error('Error processing income file:', err);
    }
  } else {
    console.error('Income file does not exist:', incomePath);
  }

  // If no income was found, add a default salary entry
  if (result.income.length === 0) {
    console.log('No income found, adding default salary entry');
    result.income.push({
      category: 'Salary',
      amount: 65000,
      description: 'Monthly Salary'
    });
  }

  console.log(`Processed data summary:`);
  console.log(`Income entries: ${result.income.length}`);
  console.log(`Expense entries: ${result.expenses.length}`);

  if (result.income.length > 0) {
    console.log('Sample income:', result.income.slice(0, 2));
  }

  if (result.expenses.length > 0) {
    console.log('Sample expenses:', result.expenses.slice(0, 2));
  }

  return result;
}

// API Routes
// Get financial data
app.get('/api/financial-data', (req, res) => {
  res.json(financialService.getFinancialData());
});

// Refresh Excel data from the file
app.post('/api/refresh-data', (req, res) => {
  try {
    console.log(`Manually refreshing data from Excel files`);
    const success = loadExcelData();

    if (success) {
      res.json({
        success: true,
        message: 'Data refreshed successfully',
        data: financialService.getFinancialData()
      });
    } else {
      res.status(500).json({
        error: 'Failed to refresh data',
        message: 'Error loading Excel data. Check server logs for details.'
      });
    }
  } catch (error) {
    console.error('Error refreshing data:', error);
    res.status(500).json({
      error: 'Failed to refresh data',
      details: error.message
    });
  }
});

// Chat message endpoint
app.post('/api/chat', express.json(), async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  try {
    // Process the query using the financial service with OpenAI
    const response = await financialService.processChatQuery(query);

    // Return the response
    res.json({ message: response });
  } catch (error) {
    console.error('Error processing chat query:', error);
    res.status(500).json({
      error: 'Failed to process query',
      message: 'Sorry, there was an error processing your request.'
    });
  }
});

// Serve the main app for any other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Budget Dashboard is running on http://localhost:${PORT}`);
  console.log(`Press Ctrl+C to stop the server`);
});

// Handle process termination
process.on('SIGINT', () => {
  console.log('Shutting down...');
  fileWatcher.stopFileWatchers(EXCEL_FILE_PATH, INCOME_EXCEL_PATH);
  process.exit();
});