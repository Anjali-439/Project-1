// public/js/dashboard.js - Client-side JavaScript for Budget Dashboard

// State management
let financialData = null;
let activeTab = 'overview';
let messages = [
  { role: 'bot', content: 'Hi! I\'m your personal finance assistant. Ask me anything about your budget or for financial advice!' }
];
let isLoading = false;

// Initialize the dashboard when the document is ready
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Fetch financial data from API
    const response = await fetch('/api/financial-data');
    if (!response.ok) {
      throw new Error('Failed to fetch financial data');
    }

    financialData = await response.json();
    render();
  } catch (error) {
    console.error('Error loading data:', error);
    document.getElementById('app').innerHTML = `
      <div class="container">
        <div class="error-message">
          <h2>Error Loading Data</h2>
          <p>${error.message}</p>
          <button class="btn btn-primary" onclick="location.reload()">Try Again</button>
        </div>
      </div>
    `;
  }
});

// Render the dashboard based on current state
function render() {
  const app = document.getElementById('app');

  // If data is not loaded yet, show loading state
  if (!financialData) {
    app.innerHTML = `
      <div class="loading-container">
        <div class="loading-spinner"></div>
        <p>Loading your financial data...</p>
      </div>
    `;
    return;
  }

  // Calculate financial summary
  const { income, expenses } = financialData;
  const totalIncome = income.reduce((sum, item) => sum + item.amount, 0);
  const totalExpenses = expenses.reduce((sum, item) => sum + item.amount, 0);
  const savings = totalIncome - totalExpenses;
  const savingsRate = totalIncome > 0 ? (savings / totalIncome) * 100 : 0;

  // Group expenses by category
  const categoryGroups = {};
  expenses.forEach(item => {
    if (!categoryGroups[item.category]) {
      categoryGroups[item.category] = 0;
    }
    categoryGroups[item.category] += item.amount;
  });

  // Convert to array for visualization
  const categoryData = Object.entries(categoryGroups).map(([category, amount]) => ({
    category,
    amount,
    percentage: (amount / totalExpenses) * 100
  }));

  // Sort categories by amount
  categoryData.sort((a, b) => b.amount - a.amount);

  // Create category grouping by type
  const expenseCategories = {
    'Housing': ['Rent', 'Electricity Bill', 'Water Bill'],
    'Food': ['Groceries', 'Dining Out'],
    'Transportation': ['Travel', 'Fuel', 'Loan EMI'],
    'Entertainment': ['Entertainment', 'Streaming Sub'],
    'Personal': ['Shopping', 'Miscellaneous', 'Gym'],
    'Technology': ['Internet', 'Mobile Bill', 'Subscriptions'],
    'Financial': ['Health Insurance', 'SIP Investment']
  };

  // Group by major categories
  const majorCategories = {};
  Object.entries(expenseCategories).forEach(([majorCategory, subCategories]) => {
    majorCategories[majorCategory] = 0;

    subCategories.forEach(subCategory => {
      const amount = categoryGroups[subCategory] || 0;
      majorCategories[majorCategory] += amount;
    });
  });

  // Convert major categories to array
  const majorCategoryData = Object.entries(majorCategories).map(([category, amount]) => ({
    category,
    amount,
    percentage: (amount / totalExpenses) * 100
  }));

  // Sort major categories by amount
  majorCategoryData.sort((a, b) => b.amount - a.amount);

  // Build the UI
  app.innerHTML = `
    <header>
      <h1>Personal Budget Dashboard</h1>
      <p>Monthly Financial Overview</p>
    </header>

    <div class="tabs">
      <button class="tab ${activeTab === 'overview' ? 'active' : ''}" onclick="changeTab('overview')">
        <i class="fas fa-home"></i> Overview
      </button>
      <button class="tab ${activeTab === 'expenses' ? 'active' : ''}" onclick="changeTab('expenses')">
        <i class="fas fa-chart-pie"></i> Expenses
      </button>
      <button class="tab ${activeTab === 'income' ? 'active' : ''}" onclick="changeTab('income')">
        <i class="fas fa-wallet"></i> Income
      </button>
      <button class="tab ${activeTab === 'savings' ? 'active' : ''}" onclick="changeTab('savings')">
        <i class="fas fa-piggy-bank"></i> Savings
      </button>
      <button class="tab ${activeTab === 'chatbot' ? 'active' : ''}" onclick="changeTab('chatbot')">
        <i class="fas fa-robot"></i> AI Assistant
      </button>
    </div>

    <div class="container">
      <div class="dashboard-content">
        ${renderTabContent(activeTab, {
          totalIncome,
          totalExpenses,
          savings,
          savingsRate,
          categoryData,
          majorCategoryData,
          income,
          expenses,
          categoryGroups
        })}
      </div>
    </div>
  `;

  // If chatbot tab is active, scroll to bottom of messages
  if (activeTab === 'chatbot') {
    setTimeout(scrollToBottom, 100);
  }
}

// Render content for the active tab
function renderTabContent(tab, data) {
  const {
    totalIncome,
    totalExpenses,
    savings,
    savingsRate,
    categoryData,
    majorCategoryData,
    income,
    expenses,
    categoryGroups
  } = data;

  switch(tab) {
    case 'overview':
      return `
        <div style="padding: 1.5rem;">
          <div class="grid">
            <div class="summary-card">
              <h3>Total Income</h3>
              <div class="amount income">₹${totalIncome.toLocaleString()}</div>
            </div>
            <div class="summary-card">
              <h3>Total Expenses</h3>
              <div class="amount expense">₹${totalExpenses.toLocaleString()}</div>
            </div>
            <div class="summary-card">
              <h3>Savings</h3>
              <div class="amount savings">₹${savings.toLocaleString()}</div>
              <div>Savings Rate: ${savingsRate.toFixed(1)}%</div>
            </div>
          </div>

          <div class="table-container">
            <h3>Top Expense Categories</h3>
            <div style="overflow-x: auto;">
              <table>
                <thead>
                  <tr>
                    <th>Category</th>
                    <th class="text-right">Amount (₹)</th>
                    <th class="text-right">% of Total</th>
                  </tr>
                </thead>
                <tbody>
                  ${categoryData.length > 0 ?
                    categoryData.slice(0, 8).map(cat => `
                      <tr>
                        <td>${cat.category}</td>
                        <td class="text-right">${cat.amount.toLocaleString()}</td>
                        <td class="text-right">${cat.percentage.toFixed(1)}%</td>
                      </tr>
                    `).join('') :
                    '<tr><td colspan="3" class="text-center">No expense data available</td></tr>'
                  }
                </tbody>
              </table>
            </div>
          </div>

          <div class="analysis-section">
            <h3>Budget Analysis & Recommendations</h3>
            <ul>
              ${savingsRate < 20 ?
                '<li>Try to save at least 20% of your income for financial security.</li>' :
                '<li>Great job! You\'re saving more than 20% of your income.</li>'}
              ${categoryGroups['Dining Out'] > 3000 ?
                '<li>Your dining out expenses are relatively high. Consider cooking more meals at home.</li>' : ''}
              ${categoryGroups['Shopping'] > 4000 ?
                '<li>Your shopping expenses are significant. Consider creating a shopping budget.</li>' : ''}
              <li>Regularly review subscription services to eliminate unnecessary ones.</li>
              <li>Consider increasing your investments for long-term financial growth.</li>
            </ul>
          </div>

          <div style="margin-top: 1.5rem; text-align: center;">
            <button class="btn btn-primary" onclick="refreshData()">
              <i class="fas fa-sync-alt"></i> Refresh Data from Excel Files
            </button>
            <p style="font-size: 0.8rem; color: #666; margin-top: 0.5rem;">
              Click this button after updating your Excel files to see the latest data
            </p>
          </div>
        </div>
      `;

    case 'expenses':
      return `
        <div style="padding: 1.5rem;">
          <h2>Detailed Expenses</h2>
          <div style="overflow-x: auto;">
            <table>
              <thead>
                <tr>
                  <th>Category</th>
                  <th class="text-right">Amount (₹)</th>
                  <th class="text-right">% of Total</th>
                  <th>Description</th>
                </tr>
              </thead>
              <tbody>
                ${expenses.length > 0 ?
                  expenses.map(expense => `
                    <tr>
                      <td>${expense.category}</td>
                      <td class="text-right">${expense.amount.toLocaleString()}</td>
                      <td class="text-right">
                        ${totalExpenses > 0 ? ((expense.amount / totalExpenses) * 100).toFixed(1) : '0.0'}%
                      </td>
                      <td>${expense.description}</td>
                    </tr>
                  `).join('') :
                  '<tr><td colspan="4" class="text-center">No expense data available</td></tr>'
                }
                ${expenses.length > 0 ?
                  `<tr class="table-footer">
                    <td>Total</td>
                    <td class="text-right">${totalExpenses.toLocaleString()}</td>
                    <td class="text-right">100%</td>
                    <td></td>
                  </tr>` : ''
                }
              </tbody>
            </table>
          </div>

          <div style="margin-top: 1.5rem; text-align: center;">
            <button class="btn btn-primary" onclick="refreshData()">
              <i class="fas fa-sync-alt"></i> Refresh Data
            </button>
          </div>
        </div>
      `;

    case 'income':
      return `
        <div style="padding: 1.5rem;">
          <h2>Income Details</h2>
          <div style="overflow-x: auto;">
            <table>
              <thead>
                <tr>
                  <th>Source</th>
                  <th class="text-right">Amount (₹)</th>
                  <th>Description</th>
                </tr>
              </thead>
              <tbody>
                ${income.length > 0 ?
                  income.map(item => `
                    <tr>
                      <td>${item.category}</td>
                      <td class="text-right">${item.amount.toLocaleString()}</td>
                      <td>${item.description}</td>
                    </tr>
                  `).join('') :
                  '<tr><td colspan="3" class="text-center">No income data available</td></tr>'
                }
                ${income.length > 0 ?
                  `<tr class="table-footer">
                    <td>Total</td>
                    <td class="text-right">${totalIncome.toLocaleString()}</td>
                    <td></td>
                  </tr>` : ''
                }
              </tbody>
            </table>
          </div>

          <div class="analysis-section">
            <h3>Income Analysis</h3>
            <p>You have a single income source. For greater financial security, consider:</p>
            <ul>
              <li>Developing additional income streams</li>
              <li>Exploring investment options for passive income</li>
              <li>Building emergency funds (3-6 months of expenses)</li>
            </ul>
          </div>

          <div style="margin-top: 1.5rem; text-align: center;">
            <button class="btn btn-primary" onclick="refreshData()">
              <i class="fas fa-sync-alt"></i> Refresh Data
            </button>
          </div>
        </div>
      `;

    case 'savings':
      return `
        <div style="padding: 1.5rem;">
          <h2>Savings & Financial Health</h2>

          <div class="grid">
            <div class="summary-card">
              <h3>Monthly Savings</h3>
              <div class="amount savings">₹${savings.toLocaleString()}</div>
              <p>(${savingsRate.toFixed(1)}% of income)</p>

              <div class="progress-container">
                <div
                  class="progress-bar ${savingsRate >= 20 ? 'good' : savingsRate >= 10 ? 'warning' : 'danger'}"
                  style="width: ${Math.min(savingsRate, 100)}%;">
                </div>
              </div>
              <div class="progress-labels">
                <span>0%</span>
                <span>Recommended: 20%</span>
                <span>50%</span>
              </div>
            </div>

            <div class="summary-card">
              <h3>Financial Health Score</h3>
              <div class="health-indicator">
                <div class="health-score">
                  ${savingsRate >= 30 ? 'A' : savingsRate >= 20 ? 'B' : savingsRate >= 10 ? 'C' : 'D'}
                </div>
                <div class="health-details">
                  <p class="health-label">
                    ${savingsRate >= 30 ? 'Excellent' :
                     savingsRate >= 20 ? 'Good' :
                     savingsRate >= 10 ? 'Fair' : 'Needs Improvement'}
                  </p>
                  <p class="health-description">Based on savings rate and expense distribution</p>
                </div>
              </div>
            </div>
          </div>

          <div class="table-container">
            <h3>Savings Growth Projection</h3>
            <p>If you maintain your current savings of ₹${savings.toLocaleString()}/month:</p>

            <table>
              <thead>
                <tr>
                  <th>Period</th>
                  <th class="text-right">Amount Saved</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1 Year</td>
                  <td class="text-right">₹${(savings * 12).toLocaleString()}</td>
                </tr>
                <tr>
                  <td>3 Years</td>
                  <td class="text-right">₹${(savings * 36).toLocaleString()}</td>
                </tr>
                <tr>
                  <td>5 Years</td>
                  <td class="text-right">₹${(savings * 60).toLocaleString()}</td>
                </tr>
                <tr>
                  <td>10 Years</td>
                  <td class="text-right">₹${(savings * 120).toLocaleString()}</td>
                </tr>
              </tbody>
            </table>
            <p style="margin-top: 0.5rem; font-size: 0.8rem; color: #666;">*Simple calculation without considering interest or investment returns</p>
          </div>

          <div style="margin-top: 1.5rem; text-align: center;">
            <button class="btn btn-primary" onclick="refreshData()">
              <i class="fas fa-sync-alt"></i> Refresh Data
            </button>
          </div>
        </div>
      `;

    case 'chatbot':
      return `
        <div class="chat-container">
          <div class="chat-header">
            <h2><i class="fas fa-robot"></i> Finance AI Assistant</h2>
            <p>Ask questions about your budget or get financial advice</p>
          </div>

          <div class="chat-messages" id="chat-messages">
            ${messages.map(msg => `
              <div class="${msg.role === 'user' ? 'message user-message' : 'message bot-message'}">
                <div class="message-header">
                  ${msg.role === 'user'
                    ? '<i class="fas fa-user"></i> You'
                    : '<i class="fas fa-robot"></i> Finance AI'}
                </div>
                <div class="message-content ${msg.isError ? 'error-message' : ''}">
                  ${msg.content}
                </div>
              </div>
            `).join('')}

            ${isLoading ? `
              <div class="message bot-message">
                <div class="message-header">
                  <i class="fas fa-robot"></i> Finance AI
                </div>
                <div class="message-content">
                  <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </div>
            ` : ''}
          </div>

          <div class="chat-input">
            <input
              type="text"
              id="chat-input-field"
              placeholder="Ask about your budget or financial advice..."
              onkeypress="if(event.key === 'Enter') sendMessage()"
            />
            <button onclick="sendMessage()" ${isLoading ? 'disabled' : ''}>
              <i class="fas fa-paper-plane"></i>
            </button>
          </div>
        </div>
      `;

    default:
      return `<div style="padding: 1rem;">Select a tab to view details</div>`;
  }
}

// Change active tab
function changeTab(tab) {
  activeTab = tab;
  render();

  if (tab === 'chatbot') {
    setTimeout(scrollToBottom, 100);
  }
}

// Function to refresh data from Excel file
function refreshData() {
  fetch('/api/refresh-data', { method: 'POST' })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        financialData = data.data;
        render();

        // Add a message to the chat
        messages.push({
          role: 'bot',
          content: 'I\'ve refreshed the financial data from your Excel files. The dashboard has been updated with the latest information.'
        });

        // Notify user
        alert('Financial data has been refreshed successfully.');
      } else {
        alert('Error refreshing data: ' + (data.error || 'Unknown error'));
      }
    })
    .catch(error => {
      console.error('Error refreshing data:', error);
      alert('Error refreshing data: ' + error.message);
    });
}

// Send chat message
async function sendMessage() {
  const inputField = document.getElementById('chat-input-field');
  const message = inputField.value.trim();

  if (message === '' || isLoading) return;

  // Add user message to chat
  messages.push({ role: 'user', content: message });
  inputField.value = '';
  isLoading = true;
  render();
  scrollToBottom();

  try {
    // Send message to API
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ query: message })
    });

    if (!response.ok) {
      throw new Error('Failed to get response from AI');
    }

    const data = await response.json();

    // Add bot response to chat
    messages.push({ role: 'bot', content: data.message });
  } catch (error) {
    console.error('Error sending message:', error);
    messages.push({
      role: 'bot',
      content: 'Sorry, there was an error processing your request. Please try again.',
      isError: true
    });
  } finally {
    isLoading = false;
    render();
    scrollToBottom();
  }
}

// Scroll chat to bottom
function scrollToBottom() {
  const chatMessages = document.getElementById('chat-messages');
  if (chatMessages) {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
}