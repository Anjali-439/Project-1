// routes/api.js - API endpoints for the budget dashboard
const express = require('express');
const financialService = require('../services/financialService');

const router = express.Router();

// GET financial data
router.get('/financial-data', (req, res) => {
  const data = financialService.getFinancialData();
  res.json(data);
});

// POST set OpenAI API key
router.post('/set-openai-key', express.json(), (req, res) => {
  const { apiKey } = req.body;

  if (!apiKey) {
    return res.status(400).json({ error: 'API key is required' });
  }

  const success = financialService.setOpenAIKey(apiKey);

  if (success) {
    res.json({ message: 'OpenAI API key has been set successfully' });
  } else {
    res.status(500).json({ error: 'Failed to set OpenAI API key' });
  }
});

// POST chat message
router.post('/chat', express.json(), async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  // Process chat query
  try {
    const response = await financialService.processChatQuery(query);

    // Simulate small delay for more natural interaction
    setTimeout(() => {
      res.json({ message: response });
    }, 300);
  } catch (error) {
    console.error('Error processing chat query:', error);
    res.status(500).json({
      error: 'Failed to process query',
      message: 'Sorry, there was an error processing your request.'
    });
  }
});

module.exports = router;