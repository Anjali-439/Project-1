// routes/index.js - Configure and export all API routes
const express = require('express');
const apiRoutes = require('./api');

const router = express.Router();

// Register API routes
router.use('/', apiRoutes);

module.exports = router;