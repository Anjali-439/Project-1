// services/financialService.js - Financial data and chat processing
const { OpenAI } = require('openai');

// Initialize OpenAI (will be set when API key is provided)
let openai = null;

// Financial data storage
let financialData = {
  income: [
    { category: 'Salary', amount: 65000, description: 'Monthly Salary' }
  ],
  expenses: [
    { category: 'Groceries', amount: 6000, description: 'Monthly groceries' },
    { category: 'Groceries', amount: 1800, description: 'Additional groceries' },
    { category: 'Dining Out', amount: 2000, description: 'Weekend restaurant visits' },
    { category: 'Dining Out', amount: 1800, description: 'Food delivery' },
    { category: 'Shopping', amount: 4500, description: 'Clothes, gadgets, etc.' },
    { category: 'Travel', amount: 2800, description: 'Cab fares, office commute' },
    { category: 'Fuel', amount: 2000, description: 'Petrol' },
    { category: 'Entertainment', amount: 2200, description: 'Movies, concerts, etc.' },
    { category: 'Miscellaneous', amount: 1900, description: 'Gifts, personal care' },
    { category: 'Subscriptions', amount: 1000, description: 'Magazines, apps' },
    { category: 'Rent', amount: 10000, description: 'Monthly rent' },
    { category: 'Electricity Bill', amount: 1200, description: 'Domestic electricity' },
    { category: 'Internet', amount: 1000, description: 'Fiber broadband' },
    { category: 'Mobile Bill', amount: 500, description: 'Postpaid plan' },
    { category: 'Health Insurance', amount: 1500, description: 'Monthly premium' },
    { category: 'SIP Investment', amount: 2000, description: 'Mutual fund SIP' },
    { category: 'Loan EMI', amount: 3000, description: 'EMI for scooter' },
    { category: 'Water Bill', amount: 500, description: 'Society water maintenance' },
    { category: 'Streaming Sub', amount: 700, description: 'OTT subscription' },
    { category: 'Gym', amount: 3000, description: 'Gym membership' }
  ]
};

const financialService = {
  /**
   * Set OpenAI API key
   * @param {string} apiKey - OpenAI API key
   */
  setOpenAIKey: (apiKey) => {
    try {
      // Use provided API key or default key
      const key = apiKey || 'sk-EyG39aGtwvRGsTjsbN-EbK_JfTvEG_wno21CeQnItsT3BlbkFJIHUP2TG5969y8w7GUEDCyMlVJ_hyCTnl6R7pDr5ysA';

      openai = new OpenAI({
        apiKey: key
      });
      console.log('OpenAI initialized successfully');
      return true;
    } catch (error) {
      console.error('Error initializing OpenAI:', error);
      return false;
    }
  },

  /**
   * Update financial data from Excel
   * @param {Object} data - New financial data with income and expenses
   */
  updateFinancialData: (data) => {
    if (!data) {
      console.error('No data provided to updateFinancialData');
      return false;
    }

    console.log('Updating financial data:');
    console.log(`- Income entries: ${data.income?.length || 0}`);
    console.log(`- Expense entries: ${data.expenses?.length || 0}`);

    // Update the financial data
    if (data.income && Array.isArray(data.income)) {
      financialData.income = [...data.income];
    }

    if (data.expenses && Array.isArray(data.expenses)) {
      financialData.expenses = [...data.expenses];
    }

    return true;
  },

  /**
   * Get all financial data
   * @returns {Object} Financial data including income and expenses
   */
  getFinancialData: () => {
    return financialData;
  },

  /**
   * Calculate financial metrics based on income and expenses
   * @returns {Object} Financial metrics
   */
  calculateFinancialMetrics: () => {
    const { income, expenses } = financialData;
    const totalIncome = income.reduce((sum, item) => sum + item.amount, 0);
    const totalExpenses = expenses.reduce((sum, item) => sum + item.amount, 0);
    const savings = totalIncome - totalExpenses;
    const savingsRate = (savings / totalIncome) * 100;

    // Group expenses by category
    const categoryGroups = {};
    expenses.forEach(item => {
      if (!categoryGroups[item.category]) {
        categoryGroups[item.category] = 0;
      }
      categoryGroups[item.category] += item.amount;
    });

    // Convert to array for visualization
    const categoryData = Object.entries(categoryGroups).map(([category, amount]) => ({
      category,
      amount,
      percentage: (amount / totalExpenses) * 100
    }));

    // Sort categories by amount
    categoryData.sort((a, b) => b.amount - a.amount);

    return {
      totalIncome,
      totalExpenses,
      savings,
      savingsRate,
      categoryGroups,
      categoryData
    };
  },

  /**
   * Process chat queries with OpenAI
   * @param {string} query - User query
   * @returns {Promise<string>} Response message
   */
  processChatQuery: async (query) => {
    const metrics = financialService.calculateFinancialMetrics();
    const {
      totalIncome,
      totalExpenses,
      savings,
      savingsRate,
      categoryGroups,
      categoryData
    } = metrics;

    // If OpenAI is configured, use it for responses
    if (openai) {
      try {
        const financialContext = `
Financial data:
- Total monthly income: ₹${totalIncome}
- Total monthly expenses: ₹${totalExpenses}
- Monthly savings: ₹${savings} (${savingsRate.toFixed(1)}% of income)
- Top expense categories: ${categoryData.slice(0, 5).map(cat => `${cat.category} (₹${cat.amount})`).join(', ')}
- Investment: ₹${categoryGroups['SIP Investment'] || 0} monthly in mutual funds
        `;

        const completion = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            {
              role: "system",
              content: `You are a helpful financial advisor assistant. Use the financial data provided to give personalized advice.

${financialContext}

Keep your responses focused on financial advice and insights about the user's budget.
Be specific, using the actual numbers from their budget.
Responses should be concise (1-3 paragraphs maximum).`
            },
            { role: "user", content: query }
          ],
          max_tokens: 300,
          temperature: 0.7,
        });

        return completion.choices[0].message.content;
      } catch (error) {
        console.error('Error with OpenAI:', error);
        // Fall back to simulated responses if OpenAI fails
        return financialService.getSimulatedResponse(query, metrics);
      }
    } else {
      // Use simulated responses if OpenAI is not configured
      return financialService.getSimulatedResponse(query, metrics);
    }
  },

  /**
   * Generate simulated responses when OpenAI is not available
   * @param {string} query - User query
   * @param {Object} metrics - Financial metrics
   * @returns {string} Simulated response
   */
  getSimulatedResponse: (query, metrics) => {
    const {
      totalIncome,
      totalExpenses,
      savings,
      savingsRate,
      categoryGroups,
      categoryData
    } = metrics;

    const queryLower = query.toLowerCase();

    if (queryLower.includes('savings') || queryLower.includes('save')) {
      return `Your current monthly savings are ₹${savings.toLocaleString()} which is ${savingsRate.toFixed(1)}% of your income. Financial experts recommend saving at least 20% of your income, so you're ${savingsRate >= 20 ? 'doing well!' : 'below the recommended threshold.'}`;
    }
    else if (queryLower.includes('expense') || queryLower.includes('spend')) {
      const topExpenses = categoryData.slice(0, 3).map(cat =>
        `${cat.category} (₹${cat.amount.toLocaleString()}, ${cat.percentage.toFixed(1)}%)`
      );

      return `Your total monthly expenses are ₹${totalExpenses.toLocaleString()}. Your highest spending categories are ${topExpenses.join(', ')}.`;
    }
    else if (queryLower.includes('income')) {
      return `Your monthly income is ₹${totalIncome.toLocaleString()} from your salary. Having multiple income streams can increase your financial security.`;
    }
    else if (queryLower.includes('invest') || queryLower.includes('investment')) {
      const investment = categoryGroups['SIP Investment'] || 0;
      const investmentPercentage = (investment / totalIncome) * 100;

      return `You're currently investing ₹${investment.toLocaleString()} monthly (${investmentPercentage.toFixed(1)}% of income) in mutual funds. Financial experts recommend investing 15-20% of your income for long-term growth.`;
    }
    else if (queryLower.includes('budget') || queryLower.includes('advice')) {
      return `Based on your spending patterns, you could potentially save more by reducing dining out expenses (currently ₹${(categoryGroups['Dining Out'] || 0).toLocaleString()}) and reviewing your subscription services. Creating a specific budget for shopping might also help control those expenses.`;
    }
    else if (queryLower.includes('recommend') || queryLower.includes('suggestion')) {
      return `Here are some personalized recommendations:\n1. Build an emergency fund of 3-6 months of expenses\n2. Consider increasing your investments\n3. Review your ₹${(categoryGroups['Dining Out'] || 0).toLocaleString()} dining expenses\n4. Track your shopping expenses more closely\n5. Consider negotiating bills like Internet (₹${(categoryGroups['Internet'] || 0).toLocaleString()}) and subscriptions`;
    }
    else {
      return `I'm your financial assistant focused on your budget data. I can help with questions about your income (₹${totalIncome.toLocaleString()}), expenses (₹${totalExpenses.toLocaleString()}), savings (₹${savings.toLocaleString()}), or provide financial recommendations.`;
    }
  }
};

module.exports = financialService;